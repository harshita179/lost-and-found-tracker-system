const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));

app.get('/', (req, res) => {
  res.send('Lost and Found API running');
});

mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/lostfound')
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.log('MongoDB connection error:', err.message));

const authRoutes = require('./routes/auth');
console.log('authRoutes loaded');

const itemRoutes = require('./routes/items');
console.log('itemRoutes loaded', typeof itemRoutes);

app.use('/auth', authRoutes);
app.use('/api/items', itemRoutes);
console.log('/api/items route mounted');

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});