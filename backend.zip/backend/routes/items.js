
console.log('items.js file loaded');
const express = require('express');
const router = express.Router();
const Item = require('../models/Item');
const verifyToken = require('../middleware/auth');
const multer = require('multer');

// multer setup
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage });

// test route
router.get('/test', (req, res) => {
  res.json({ message: 'items route working' });
});

// get all items
router.get('/', async (req, res) => {
  try {
    const { itemType, status } = req.query;
    let filter = {};

    if (itemType) filter.itemType = itemType;
    if (status) filter.status = status;

    const items = await Item.find(filter).populate('reportedBy', 'username email');
    res.json(items);
  } catch (err) {
    console.log('GET ITEMS ERROR:', err.message);
    res.status(500).json({ message: err.message });
  }
});

// get single item
router.get('/:id', async (req, res) => {
  try {
    const item = await Item.findById(req.params.id).populate('reportedBy', 'username email');

    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    res.json(item);
  } catch (err) {
    console.log('GET ITEM ERROR:', err.message);
    res.status(500).json({ message: err.message });
  }
});

// create item
router.post('/', verifyToken, upload.single('image'), async (req, res) => {
  try {
    const item = new Item({
      title: req.body.title,
      description: req.body.description,
      location: req.body.location,
      category: req.body.category,
      itemType: req.body.itemType,
      dateLost: req.body.dateLost,
      status: req.body.status || 'open',
      reportedBy: req.userId,
      image: req.file ? req.file.path : null
    });

    const newItem = await item.save();
    await newItem.populate('reportedBy', 'username email');

    res.status(201).json(newItem);
  } catch (err) {
    console.log('CREATE ITEM ERROR:', err.message);
    res.status(400).json({ message: err.message });
  }
});

// update item
router.patch('/:id', verifyToken, async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);

    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    if (item.reportedBy.toString() !== req.userId && req.userRole !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to update this item' });
    }

    if (req.body.title) item.title = req.body.title;
    if (req.body.description) item.description = req.body.description;
    if (req.body.location) item.location = req.body.location;
    if (req.body.category) item.category = req.body.category;
    if (req.body.itemType) item.itemType = req.body.itemType;
    if (req.body.status) item.status = req.body.status;
    if (req.body.found !== undefined) item.found = req.body.found;
    if (req.body.image) item.image = req.body.image;

    item.updatedAt = new Date();

    const updatedItem = await item.save();
    await updatedItem.populate('reportedBy', 'username email');

    res.json(updatedItem);
  } catch (err) {
    console.log('UPDATE ITEM ERROR:', err.message);
    res.status(500).json({ message: err.message });
  }
});

// delete item
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);

    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    if (item.reportedBy.toString() !== req.userId && req.userRole !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to delete this item' });
    }

    await Item.findByIdAndDelete(req.params.id);
    res.json({ message: 'Item deleted successfully' });
  } catch (err) {
    console.log('DELETE ITEM ERROR:', err.message);
    res.status(500).json({ message: err.message });
  }
});

// mark found
router.patch('/:id/mark-found', verifyToken, async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);

    if (!item) {
      return res.status(404).json({ message: 'Item not found' });
    }

    item.found = true;
    item.status = 'resolved';
    item.updatedAt = new Date();

    const updatedItem = await item.save();
    await updatedItem.populate('reportedBy', 'username email');

    res.json(updatedItem);
  } catch (err) {
    console.log('MARK FOUND ERROR:', err.message);
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;